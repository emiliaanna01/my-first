# Scripts: which one for which step

The plugin ships Python scripts for every repeatable step. **Run them; don't rewrite them for a video.** Everything
that differs between videos lives in JSON files of the video (`edit/<id>/cut.json`, `reel.json`, `visual_plan.json`),
not in code. Each script prints its full help with `--help`.

## How to run

```bash
cd {{PROJECT_ROOT}}
python "${CLAUDE_SKILL_DIR}/scripts/<name>.py" <command> [args]
```

- Use `python3` where `python` is Python 2 or missing; on Windows `py -3` also works. Python 3.9+ and ffmpeg/ffprobe
  in PATH. Pillow (`pip install Pillow`) for contact sheets, covers, brand logos and meme previews; OpenCV
  (`pip install opencv-python-headless`) only for face measurement.
- Run from the project folder: the scripts find it as the current folder or above (the nearest folder with `edit/` or
  `brands/`, or `it-reelsmaker.json -> project_root`), or from `REELS_PROJECT`. `edit/<id>` arguments are relative to it.
- The scripts write only into the project (and the Remotion project you name), never into the plugin folder: an
  update replaces it. Your own defaults go into `{{PROJECT_ROOT}}/reel-defaults.json` (`reelcfg.py defaults`; layers:
  `references/brands.md`, “Your settings in the project”).
- Exit codes: `0` done (warnings start with an exclamation mark and don't stop the edit); `1` a check failed (plan errors, a
  rough cut whose video and audio don't line up, a master that missed the target): fix it before going on.
- Several sessions in one project are safe: shared JSON is written atomically under a lock.

## By step

| Step | Script | Commands |
|---|---|---|
| 0 | `doctor.py` | the environment in one command: what is missing and the install command for this OS (exit 1 if a required program is missing) |
| 0, 8 | `kit.py` | `new <folder>` (a starter Remotion project: pinned versions, `Root.tsx` with `ReelKit`, `ReelCover` and the code scenes; prints the `npm install` command), `check --remotion <dir>` (kit version and changed files), `update --remotion <dir> [--dry-run]` (replaces only `src/ReelKit.tsx` and `src/kit/`, backup in `.kit-backup/`; line endings alone are not a difference; refuses to roll back a project kit newer than the plugin's without `--force`) |
| 0 | `brand.py` | `list`, `show <slug>` (profile, contrast, found files; the rules, video guide, CTA library and other brand documents, ✗ if missing), `new --name … --colors … [--tone …]`, `logo`, `rule <slug> "<text>"` (append a brand-level rule to `rules.md`), `set`, `tone <slug> <preset>`, `use <slug> --edit edit/<id>`, `export <slug> --remotion <dir>` |
| 0 | `reelcfg.py` | `show edit/<id> [--json]` (settings, where each comes from: `defaults`, `project`, `overlay`, `tone:<preset>`, `brand:<slug>`, `reel.json`, `override`; what will actually turn on and why not; the format); `save edit/<id> --set key=value …` (`format=framed` with optional `label="…"` and `window=[x,y,w,h]`: a horizontal source in a window the kit draws, `references/techniques.md`; a bad window or format is not saved); `defaults` (print the project defaults file `reel-defaults.json`), `defaults --set key=value …` (write `settings` keys), `defaults --unset key …` (remove keys) |
| 2, 3 | `transcribe.py` | `edit/<id> <source> [--model medium] [--language ru]` (faster-whisper, cached in `transcripts/`); `snip edit/<id> <source> --from … --to …` (a <= 5 s piece without context, for retakes); `audio edit/<id> <source>` (only the WAV on the video timeline: feed this to your own transcriber, not the video file); `check <file>` (your own transcriber's output); `rate edit/<id> [--source KEY]` (syllables per second of the rough cut = vowels of the words ÷ speech time by the speech mask, per source and per segment: two cameras are evened out by it) |
| 1, 3a | `structure.py` | `suggest edit/<id> [--source KEY \| --transcript F] [--from S --to S] [--json]` (several sources in `cut.json` or several transcripts: name one, the script lists them instead of guessing; `--to` past the transcript's last word warns; `--from/--to`: one fragment of a long recording, source seconds; phrases with their signs: question, answer, repeat, exclamation, number, beat after, and the flags `est` (a word whose time is estimated: added by the online add-on's transcript, not heard by the local model), `retake?`, `unfinished`, explained in the output; which can be cut out cleanly by the speech mask (≥ 0.1 s of raw silence at both edges, the same rule as `speech_mask.py`, also where faster-whisper glued the pause into a word); teaser candidates with exact `ranges` (a short list by signs: 3–12 words, 0.8–4.5 s, no word with an estimated time or a retake sign; clean edges, a whole sentence and a beat after it rank higher; the agent picks by meaning); slow start; ending; earlier edits; writes `structure.json`), `history edit/<id> \| <source>` (other edit folders with the same source) |
| 3, 6 | `speech_mask.py` | `<audio.wav> --spans 0.5-4.6,4.7-9.6 [--density natural]` (edges by audio → `"ranges"` for `cut.json`; a short pause with a sound within 3 dB under the threshold is flagged: a quiet syllable would be cut out with it); `--edl edit/<id>/edl.json` (check every edge of the rough cut, exit 1 on warnings) |
| 6 | `cut.py` | `edit/<id> --dry-run` (segments, lengths, words, words per speaker), then `edit/<id>` → `final.mp4`, `captions.json`, `edl.json`; the cut list format is in `--help`; `fix`/`fix_at` with `"to": ""` removes a word from the subtitles (one only the local model heard), the sound stays; a transcript word that falls in a short gap (≤ 1 s) removed between two ranges is named in a warning (dry run too): listen, it may be a quiet syllable; a word goes into the subtitles only when it is heard in the cut (the ranges hold most of it or its center, or it starts in a range and runs on in it for 0.15 s), so the tail of a removed line touching a range is not shown |
| 6 | `balance.py` | `edit/<id> [--frames 6] [--write] [--json]`: white balance measured on the graded result (frames of the kept ranges through the same look as `cut.py`, LUT included) → the `colorchannelmixer` gains for `look.correct` that make the grays neutral; numbers with no fix / current / suggested, `verify/balance.png`; `--write` puts it into `cut.json`, then run `cut.py` again. Every video, before the LUT is judged by eye. A candidate counts only while it keeps ≥ 70% of the uncorrected near-gray share; a suggestion that deepens the cast (a cool picture made cooler) is refused. `--ref [KEY:]SECOND,X,Y,W,H` (repeatable): the eyedropper, a box on a white or gray object in the frame as `cut.py` scales that source (find it on the frame that `--still [KEY:]SECOND` writes to `verify/`, at that size: a frame grabbed from a 720p source is smaller); the gains make that patch neutral after the full chain, brightness kept; patch numbers before/after, the patch outlined on `balance.png`. Use it when the frame is dominated by colored light (sky, sea, neon, mixed light) or the automatic mode refuses |
| 6, 8, 9 | `faces.py` | `scan edit/<id>` (a horizontal video in its source geometry, mapped into the “framed” window of `reel.json`), `zones edit/<id> [--cam z,cx,cy]` (a span across a change of camera angle is split into a, b, …: each piece with its own faces), `check edit/<id> --box x,y,w,h --from … --to …`, `audit out/<render>.mp4 --edit edit/<id>` (the subtitle band the render has, recorded by `visual_plan.py export` as the kit's two-line block; a face at the left or right edge of the render, or one that `faces.json` through `camera.json` puts there, is flagged: a push-in that cuts the other person in a skit; `--sub top,bottom` otherwise; the plan's `hide-subs` windows and scenes that hide subtitles are not “face in the subtitle band”; a presenter's own face in its `keep-clear --own-face` zone is not an overlap; “framed”: a face cut by the window's sides, the camera clamped to the window as the kit draws it); the model path via `--model {{FACE_MODEL}}` or `face_model` in `it-reelsmaker.json` |
| 7a | `visual_plan.py` | `init edit/<id>` (with every insert off too: `export` needs the plan; a “scenes only” promo: `init edit/promo-<brand> --scenes-only --duration 20 [--brand <slug>]`, seconds, 15–25), `add` (B-roll, meme, designed scene), `keep-clear` (`--remove N`: a zone as numbered in `visual_plan.md`; `--matte NAME --own-face x,y,w,h`: the presenter layer `matte.py place` prints: its span counts in the coverage, its own face is not a no-go, `export` copies `matte/NAME.webm` to `public/<id>/`), `hide-subs --from … --to … [--why …]` / `--remove N` (subtitles hidden by a per-video composition: into `props.hideSubtitles`, read by `faces.py audit`), `remove <insert-id>…` (to change an insert: remove, add again), `validate` (exit 1 on errors; boxes and zones are checked against faces through `camera.json`, sample by sample, as the render audit sees them; “framed”: the camera clamped to the window, boxes inside its text area, overlay and full scenes only, the hook's size, `faces.json` in source geometry, a horizontal rough cut), `md` (the table for the person), `shade edit/<id> [--color #FFFFFF] [--top Y] [--target 4.5]` (the “Typewriter” darkening measured on the rough cut: the value for 4.5:1 on the lightest frame → `reel.json subtitles_shade`; the kit draws it only in “Typewriter” mode; `--scene ID` or `--zone x,y,w,h [--from S --to S]`: a flat darkening for text in another zone, against 3:1 by default), `export --remotion <dir> [--props <file>] [--subtitles accent\|plate\|typewriter\|none] [--hook "text"] [--card LINE [LINE] \| --sting] [--corner]` (`--hook`: `props.hook`, a hook headline the kit shows for the first 2.4 s; `--sting`: the logo with `brand.tagline` at the end, no CTA; `edit/<id>/camera.json` → `props.camera`, `references/camera.md`; `reel.json → subtitles_shade` → the darkening behind “Typewriter”; `reel.json → format: framed` → `props.framed`: the window, the label, the rough cut's size, the field color, and the subtitle band kept inside the window) |
| 7a | `footage.py` | `index` + `describe` (the project's own footage), `search`, `plan-search edit/<id>`, `pick edit/<id> <insert>` (the project's own video gets the rough cut's look: `look.correct` → LUT at `lut_mix` → `look.grade`, as `cut.py`; `--no-look` turns it off), `prepare` (`--look edit/<id>`: the same look; `--grade`: a chain BEFORE `--lut`) |
| 7a | `codescene.py` | `manifest`, `validate`, `scaffold edit/<id> <insert> --remotion <dir>`, `render …`, `ingest edit/<id>` |
| 7a | `memes.py` | `index`, `set`, `search`, `prepare`, `place edit/<id> <insert>` |
| 8 | `subs.py` | `phrases edit/<id> --lang <code>` (the speech by phrases → `subs/<code>.json`, translations of unchanged phrases kept); `apply edit/<id> --lang <code>` (checks the translation → `captions-<code>.json`; `reel.json → subtitles_lang` makes the export use it); `srt edit/<id> [--lang <code>] [-o file]` (SubRip file: 2 lines of 42 characters at most, a longer phrase in several subtitles, no line ending on a short word or a number torn from its word); a phrase under 3 words or 1 s joins its neighbor in the segment |
| 8 | `matte.py` | `cut edit/<id> --from … --to … [--width 1080] [--dry]` (figure cut-out on this computer with your rembg → WebM with alpha, edge data, a cut inside the frame (table line), check frame); `place edit/<id> --name host --layout review` (presenter layout: the scale never goes above ×1.0, the face on screen and the target printed; a 720 cut-out shown above its pixels and a table line on screen are warned; prints the `keep-clear --matte … --own-face …` line) |
| 8 | `phone_screen_rect.py` | `<frame.png> [width]`: the screen rectangle of a phone mockup |
| 9 | `patch_render.py` | `out/<render>.mp4 --comp ReelKit --props <path>/edit/<id>/reelkit-props.json --from 12.3 --to 13.1`: re-render and splice a segment (late spot fixes); the props path is made absolute for Remotion; a fix in the props → `visual_plan.py export … --props` first; `--comp Reel<id>` (no `--props`) only for a per-video composition |
| 9 | `poster.py` | `pick edit/<id> --render out/x.mp4 -o cover.jpg` (a frame in a pause of the speech, a gap of the speech mask ≥ 0.15 s; a render with no sound track, as in “scenes only”: the middle of the hook's settled window; `--sheet <file>`: candidates to choose from, those on speech marked; `--t` on speech warns), `guide cover.jpg -o cover-guide.png`, `bake out/x.mp4 --cover cover.jpg -o out/x-cover.mp4` (cover in frame 0, before mastering), `attach out/x-master.mp4 --cover cover.jpg -o out/x-final.mp4` (cover art for file manager thumbnails, after mastering, nothing re-encoded) |
| 9 | `master_audio.py` | `out/render.mp4 -o out/master.mp4 [--music track.mp3] [--sfx edit/<id>/sfx.json]` (`--sfx`: scene sound accents, the kit does not play them: each sound placed by its sound start, 15 dB under the voice peak), `--duck A-B[:dB]` (duck the music under a key line: seconds of the render, −14 dB by default, repeatable; the voice untouched), `--drop-at S --drop-in-track T` (the track's drop on the final phrase), `--check` (a master of effects over silence, tagged when made, is checked without the −14 LUFS target; `--check --no-loudness` for one made before the tag), `--find-drops` |
| 11 | `library_catalog.py` | `--dir {{ASSETS_DIR}} [--verdicts <file>] [--full]`: catalog, overview sheets and verdicts of your own asset library; only changed files are measured again, `--full` measures everything again |
| — | `addon.py` | runs the commands of the online-sources add-on, if it is installed and linked (`addon.py` alone lists them) |

## The rough cut list (`edit/<id>/cut.json`)

```json
{
 "speed": 1.15,
 "sources": {"main": {"file": "IMG_4821.MOV"}},
 "look": {"correct": "colorchannelmixer=rr=0.97:bb=1.06", "lut": "brand", "lut_mix": 0.6, "grade": "eq=contrast=1.05:saturation=1.04"},
 "ranges": [{"start": 1.567, "end": 12.967, "beat": "hook", "speaker": "A"},
            {"start": 14.767, "end": 20.767, "beat": "the answer", "speaker": "B",
             "speakers": [{"from": 18.2, "to": 19.1, "speaker": "A"}]}],
 "fix": {"Akme": "Acme"},
 "retime": [{"text": "shortlist", "at": 16.16, "start": 16.10, "end": 16.62}]
}
```

`ranges` come from `speech_mask.py` (it prints them in this form), `look.correct` from `balance.py --write`. Two cameras: two `sources`, each with its own
`speed`, and `"source"` in every range. Cutaways from the same footage: `"extract": {"broll_view": {"start": 36.5,
"end": 41.5, "what": "the view from the balcony"}}` (`what` is optional: the description `footage.py` searches; the
clip is already in the rough cut's color, and `footage.py pick` takes it without a second look). Transcription fixes go into `fix` (every occurrence) or `fix_at` (one occurrence near a second; `at` is the word's start
after `retime`, so for a retimed word its new `start`). Two people: `"speaker"` on each range and `"speakers"` (source seconds, a
word belongs where its middle is) for a switch inside one; `cut.py` puts the label on every caption word, `captions.json →
"speakers"` lists them sorted, and the kit colors the subtitles per speaker (`references/skit.md`). Without them a
transcript's own labels (`"speaker"` or `"speaker_id"`) are kept.

## What the scripts don't do

The kit (`assets/remotion-kit/`, copied into the Remotion project by `kit.py`) renders the `ReelKit` and `ReelCover`
compositions from the props of `visual_plan.py export --props`: rough cut, subtitles, brand, inserts, designed scenes,
cover, the virtual camera from `camera.json`, the three subtitle modes and the “framed” layout (`props.framed`). A per-video composition reuses its exported pieces (`FramedFootage`, `FramedLabel`, `EndCard` with the logo sting, `Corner`, `cameraAt`) instead of copying them. Anything a video needs beyond that (techniques, code scenes: `references/camera.md`,
`references/techniques.md`) is written by the agent per video, on top of the kit's components. A different transcriber is fine: run it on the WAV from `transcribe.py audio` (a tool that pulls the audio out of a phone MOV itself gets every word ~0.1 s early), and its output only has to pass `transcribe.py check`.

Audio extraction writes `edit/<id>/audio16k-<source stem>.wav` for each source, with source identity metadata next to it. Pass that WAV to `speech_mask.py`. Older projects may still use `audio16k.wav` as a legacy input; new transcriptions never reuse it. Cut ranges must be finite, inside the source (one frame of end tolerance), and contain at least one output frame. Segment output sizes must match; SAR is normalized to 1:1. Extract and matte names must be safe local names.
