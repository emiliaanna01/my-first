# My video skills — everything in one folder

Everything added to the "Documentary videos" project, ready to reuse in another project or chat.

## skills/  — upload each on claude.ai (Settings → Capabilities → Skills → Upload), or unzip into `.claude/skills/` for Claude Code
| File | What it does |
|---|---|
| `it-reelsmaker.skill` | IT Reelsmaker: edits talking-head Reels/Shorts/TikToks — cuts pauses, virtual camera, word-timed subtitles, hooks/quotes/CTAs, brand profiles, −14 LUFS, 1080×1920 (Remotion). |
| `real-sfx.skill` | Real SFX (Clipwing): puts real recorded sound effects on the exact frame; 78 free UI sounds included. |
| `documentary-reel.skill` | Golden-sepia archival documentary reels (Operation Mincemeat method) incl. the saved female narrator. |

## plugins/it-reelsmaker-plugin/
The full IT Reelsmaker plugin (by IT Party Pattaya, v1.6.1) as installed, for Claude Code: copy the folder and add it as a local plugin.

## tools/earshot/  (MIT, by Leon Lin — github.com/Leonxlnx/earshot)
252 sound effects made in code (whooshes, hits, risers, shutters, paper, typing…).
Install: `pip install soxr pyloudnorm && pip install --no-deps -e tools/earshot`
Use: `earshot sfx list` · `earshot sfx render whoosh_big/swell -o whoosh.wav`

## project-toolkit/  (from the setup Google Doc)
`setup.sh` + `requirements.txt` install: auto-editor (cut silences), RobustVideoMatting background replacement (`tools/matte.py`),
Parakeet word-timed captions (`tools/captions.py`, `tools/asr.py`), compositing/scene tools, MediaPipe, rembg, Whisper-small.
`reels/` is the Remotion project the IT Reelsmaker plugin uses (`it-reelsmaker.json` points the plugin at it). Run `npm install` inside `reels/`.
`docs/motion-promo-guide.md` — the Motion Promo user guide.

## video-pipeline/  (built during our work)
- `render.cjs` — renders a canvas HTML reel to MP4 or stills with headless Chromium + ffmpeg
- `audio/dsp.py`, `audio/sfx.py`, `audio/vo.py` — synthesis, sound design and mixing helpers
- `voices/` — the saved female narrator (Kokoro 70% bf_emma + 30% af_kore) + `speak.py`
- `words.py` (word timings), `vo_el.py` (re-pace an ElevenLabs narration), `sheet.py` (contact sheets)

Not included (too big or already on your account): the Kokoro voice model files (~330 MB, from github.com/thewh1teagle/kokoro-onnx/releases),
AI models downloaded by setup.sh, the Small Business plugin and Anthropic's built-in skills (pdf, docx, pptx, xlsx, deep-research, watch…), which are already on your account.
